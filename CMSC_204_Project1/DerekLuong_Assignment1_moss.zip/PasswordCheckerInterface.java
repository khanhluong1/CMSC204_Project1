import java.util.ArrayList;


public interface PasswordCheckerInterface {

	/**
	 * check given password based on following criteria:
	 * 
	 * 1. Length must be greater than 6; a strong password will contain at least 10 characters
     * 2. Must contain at least one upper case alpha character
     * 3. Must contain at least one lower case alpha character
     * 4. Must contain at least one numeric character
     * 5. May not have more than 2 of the same character in sequence
	 * 
	 * @param passwordString password to be checked
	 * @return true if password is valid
	 * @throws LengthException when length is less than 6 characters
	 * @throws NoDigitException when no digit
	 * @throws NoUpperAlphaException when no upper char
	 * @throws NoLowerAlphaException when no lower char
	 * @throws InvalidSequenceException when having more than 2 of the same character in sequence
	 * @throws UnmatchedExcpetion when passwordString and retypedPasswordString is not matched
	 */
	public boolean isValidPassword(String passwordString) throws LengthException, NoDigitException, 
			NoUpperAlphaException, NoLowerAlphaException, InvalidSequenceException;
	
	/**
     * validate whether password and retyped password is matching
     * 
     * @param passwordString password to be checked
     * @param retypedPasswordString retyped password to be checked
     * @return true if password and retyped password is matching
     * @throws UnmatchedExcpetion when passwordString and retypedPasswordString is not matched
     */
	public boolean isPasswordMatching(String passwordString, String retypedPasswordString) throws UnmatchedExcpetion;

	/**
	 * check if password's length is between 6 and 10 characters
	 * 
	 * @param passwordString password to be checked
	 * @return true if length is between 6 and 10, otherwise false
	 */
	public boolean isWeakPassword(String passwordString);
	
	/**
	 * check given array list of passwords using method of isValidPassword
	 * 
	 * @param passwords
	 * @return array list of invalid passwords
	 */
	public ArrayList<String> validPasswords(ArrayList<String> passwords);
}
