import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class PasswordCheckerGUI extends Application {
	
	private PasswordCheckerInterface passwordChecker = new PasswordChecker();
	
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Password Checker");
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        //setHgap and setVgap set the margins outside the components
        grid.setHgap(10); 
        grid.setVgap(10);
        //setPadding sets the spacing inside each component
        grid.setPadding(new Insets(25, 25, 25, 25)); 
        String intro = "Use the following rules when creating your passwords:\n" +
        			"     1. Length must be greater than 6; a strong password will contain at least 10 characters\n" +
        			"     2. Must contain at least one upper case alpha character\n" +
        			"     3. Must contain at least one lower case alpha character\n" +
        			"     4. Must contain at least one numeric character\n" +
        			"     5. May not have more than 2 of the same character in sequence";
        Text scenetitle = new Text(intro);
        scenetitle.setFont(Font.font("ARIAL", FontWeight.NORMAL, 13));
        grid.add(scenetitle, 0, 0, 2, 1);

        Label password1 = new Label("Password:");
        grid.add(password1, 0, 1);

        TextField passwordField = new TextField();
        grid.add(passwordField, 1, 1);

        Label password2 = new Label("Re-Type Password:");
        grid.add(password2, 0, 2);

        TextField retypedPasswordField = new TextField();
        grid.add(retypedPasswordField, 1, 2);
        
        //add button to an HBox to position it to the right
        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_CENTER);
        grid.add(hbBtn, 1, 4);
        
        Button checkPasswordBtn = new Button("_Check Password");
        checkPasswordBtn.setTooltip(new Tooltip("Select to check password based on 5 criteria"));
        checkPasswordBtn.setMnemonicParsing(true);
        hbBtn.getChildren().add(checkPasswordBtn);

        //create the EventHandler class for checkPasswordBtn as an anonymous inner class
        checkPasswordBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
            	String password = passwordField.getText();
            	String retypedPassword = retypedPasswordField.getText();
            	try {
					passwordChecker.isValidPassword(password);
					passwordChecker.isPasswordMatching(password, retypedPassword);
					
					if (passwordChecker.isWeakPassword(password)) {
            			showAlertMessage(AlertType.INFORMATION, "Password Status", "Password is OK but weak");
            		} else {
            			showAlertMessage(AlertType.INFORMATION, "Password Status", "Password is Valid");
            		}
					
				} catch (LengthException | NoDigitException
						| NoUpperAlphaException | NoLowerAlphaException
						| InvalidSequenceException | UnmatchedExcpetion err) {
					
					showAlertMessage(AlertType.ERROR, "Password Error", err.getClass().getName() + ": " +  err.getMessage());
				}
            }
        });
        
        Button checkPasswordInFileBtn = new Button("Check Password In _File");
        checkPasswordInFileBtn.setTooltip(new Tooltip("Select to check multiple passwords in file based on 5 criteria"));
        checkPasswordInFileBtn.setMnemonicParsing(true);
        hbBtn.getChildren().add(checkPasswordInFileBtn);
        
        //create the EventHandler class for checkPasswordInFileBtn as an anonymous inner class
        checkPasswordInFileBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
            	ArrayList<String> passwords = new ArrayList<String>();
            	
            	FileChooser fileChooser = new FileChooser();
            	fileChooser.setTitle("Open Resource File");
            	File file = fileChooser.showOpenDialog(primaryStage);
                if (file != null) {
					try {
						// FileReader reads text files in the default encoding.
						FileReader fileReader = new FileReader(file);
						// Always wrap FileReader in BufferedReader.
	                    BufferedReader bufferedReader = new BufferedReader(fileReader);

	                    String line = null;
	                    while((line = bufferedReader.readLine()) != null) {
	                    	passwords.add(line);
	                    }   

	                    // Always close files.
	                    bufferedReader.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                }
                
                if (passwords.size() > 0) {
                	ArrayList<String> invalidPasswords = passwordChecker.validPasswords(passwords);
                	if (invalidPasswords != null && invalidPasswords.size() > 0) {
                		String errorMsg = "";
                		for (String invalidPassword : invalidPasswords) {
                			errorMsg += invalidPassword + "\n";
                		}
                		showAlertMessage(AlertType.ERROR, "Illegal Passwords", errorMsg);
                	}
                }
            }
        });
        
        
        Button exitButton = new Button("_Exit");
        exitButton.setTooltip(new Tooltip("Select to close the application"));
        exitButton.setMnemonicParsing(true);
        hbBtn.getChildren().add(exitButton);
        
        //use a lambda expression for the EventHandler class for exitButton
        exitButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
            public void handle(ActionEvent e) {
    			Platform.exit();
             	System.exit(0);
    		}
        });

        Scene scene = new Scene(grid, 600, 275);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void showAlertMessage(AlertType alertType, String title, String content) {
    	Alert alert = new Alert(alertType);
    	alert.setResizable(true);
    	alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
    }
}

