
/**
 * Throw when password doesn�t contain an uppercase alpha character
 * 
 * @author Derek Luong
 *
 */
public class NoUpperAlphaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8049785519647479986L;
	
	public NoUpperAlphaException(String msg) {
		super(msg);
	}

}
