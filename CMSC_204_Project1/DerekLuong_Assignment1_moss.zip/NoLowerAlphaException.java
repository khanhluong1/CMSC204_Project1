
/**
 * Throw when password doesn�t contain a lowercase alpha character
 * 
 * @author Derek Luong
 *
 */
public class NoLowerAlphaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8239724052859538507L;
	
	public NoLowerAlphaException(String msg) {
		super(msg);
	}

}
