
/**
 * Throw when Password contains more than 2 of the same character in sequence
 * 
 * @author Derek Luong
 *
 */
public class InvalidSequenceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -715765392266107006L;

	public InvalidSequenceException(String msg) {
		super(msg);
	}
	
}
