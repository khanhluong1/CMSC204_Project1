
/**
 * Throw when Password doesn�t contain a numeric character
 * 
 * @author Derek Luong
 *
 */
public class NoDigitException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8662017923570767150L;

	public NoDigitException(String msg) {
		super(msg);
	}
	
}
