
/**
 * Throw when Password and re-typed Password are not identical 
 * 
 * @author Derek Luong
 *
 */
public class UnmatchedExcpetion extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1265119475400857712L;

	public UnmatchedExcpetion(String msg) {
		super(msg);
	}
}
