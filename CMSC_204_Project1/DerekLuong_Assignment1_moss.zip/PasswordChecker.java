import java.util.ArrayList;

/**
 * 
 * @author Derek Luong
 *
 */
public class PasswordChecker implements PasswordCheckerInterface {

	/**
	 * see boolean PasswordCheckerInterface@isValidPassword(String)
	 */
	@Override
	public boolean isValidPassword(String passwordString)
			throws LengthException, NoDigitException, NoUpperAlphaException,
			NoLowerAlphaException, InvalidSequenceException {
		boolean isValid = true;
		
		if (passwordString == null || passwordString.length() < 6) {
			throw new LengthException("The password must be at least 6 characters long");
		}
		
		if (!isContainUpperChar(passwordString)) {
			throw new NoUpperAlphaException("The password must contain at least one uppercase alphabetic character");
		}
		
		if (!isContainLowerChar(passwordString)) {
			throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character");
		}
		
		if (!isContainNumericChar(passwordString)) {
			throw new NoDigitException("The password must contain at least one digit");
		}
		
		if (isContainMoreThanTwoSameChars(passwordString)) {
			throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");
		}
		
		return isValid;
	}
	
	/**
	 * see boolean PasswordCheckerInterface@isPasswordMatching(String, String)
	 */
	@Override
	public boolean isPasswordMatching(String passwordString, String retypedPasswordString) throws UnmatchedExcpetion {
    	boolean isValid = true;
    	
    	if (!passwordString.equals(retypedPasswordString)) {
			throw new UnmatchedExcpetion("The passwords do not match");
		}
    	
    	return isValid;
    }

	/**
	 * see boolean PasswordCheckerInterface@isWeakPassword(String)
	 */
	@Override
	public boolean isWeakPassword(String passwordString) {
		if (passwordString != null && passwordString.length() >= 6 && passwordString.length() <= 10) {
			return true;
		}
		return false;
	}

	/**
	 * see ArrayList<String> PasswordCheckerInterface@validPasswords(ArrayList<String>)
	 */
	@Override
	public ArrayList<String> validPasswords(ArrayList<String> passwords) {
		ArrayList<String> invalidPasswords = new ArrayList<String>();
		for (String password : passwords) {
    		try {
				isValidPassword(password);
				if (isWeakPassword(password)) {
					invalidPasswords.add(password + " Password is OK but weak");
				}
			} catch (LengthException | NoDigitException | NoUpperAlphaException
					| NoLowerAlphaException | InvalidSequenceException e) {
				invalidPasswords.add(password + " " + e.getMessage());
			}
    	}
		return invalidPasswords;
	}
	
	/**
	 * check if str contains at least one upper character
	 * 
	 * @param str
	 * @return
	 */
	private boolean isContainUpperChar(String str) {
		boolean isGood = false;
		if (str != null) {
			for (int i=0; i < str.length(); i++) {
				if (Character.isUpperCase(str.charAt(i))) {
					isGood = true;
					break;
				}
			}
		}
		return isGood;
	}
	
	/**
	 * check if str contains at least one lower character
	 * 
	 * @param str
	 * @return
	 */
	private boolean isContainLowerChar(String str) {
		boolean isGood = false;
		if (str != null) {
			for (int i=0; i < str.length(); i++) {
				if (Character.isLowerCase(str.charAt(i))) {
					isGood = true;
					break;
				}
			}
		}
		return isGood;
	}
	
	/**
	 * check if str contains at least one numeric character
	 * 
	 * @param str
	 * @return
	 */
	private boolean isContainNumericChar(String str) {
		boolean isGood = false;
		if (str != null) {
			for (int i=0; i < str.length(); i++) {
				if (Character.isDigit(str.charAt(i))) {
					isGood = true;
					break;
				}
			}
		}
		return isGood;
	}
	
	/**
	 * check if str contains more than 2 same character in sequence
	 * 
	 * @param str
	 * @return true if contain more than 2 same character, otherwise false
	 */
	private boolean isContainMoreThanTwoSameChars(String str) {
		boolean isGood = false;
		if (str != null) {
			for (int i=0; i < str.length() - 1; i++) {
				Character curChar = str.charAt(i);
				int numOfChar = 1;
				for (int j=i+1; j < str.length(); j++) {
					if (curChar.equals(str.charAt(j))) {
						numOfChar++;
					} else {
						numOfChar = 1;
					}
					if (numOfChar > 2) {
						return true;
					}
				}
			}
		}
		return isGood;
	}
}
