
/**
 * 
 * Throw when length of password is less than given number of characters
 * 
 * @author Derek Luong
 *
 */
public class LengthException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6067355039683548689L;
	
	public LengthException(String msg) {
		super(msg);
	}

}
